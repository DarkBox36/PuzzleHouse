To play the game, go to the build folder and run the .exe file.

Have fun!

@DeepDish36